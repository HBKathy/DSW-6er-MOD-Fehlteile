DECLARE
    i NUMBER := 1; -- Startindex für die Schleife
    max_num NUMBER := 25; -- Maximale Anzahl von ABZGL_LAGER-Spalten (ABZGL_LAGER_01 bis ABZGL_LAGER_25)
    sql_stmt VARCHAR2(4000); -- Dynamisches SQL-Statement
    sum_expr VARCHAR2(4000); -- Ausdruck für die Summierung
BEGIN
    -- Dynamischer Ausdruck für die Summierung
    sum_expr := '';
    FOR i IN 1..max_num LOOP
        IF i > 1 THEN
            sum_expr := sum_expr || ' + ';
        END IF;
        sum_expr := sum_expr || 'NVL(ABZGL_LAGER_' || LPAD(i, 2, '0') || ', 0)';
    END LOOP;

    -- Generiere das vollständige UPDATE-Statement
    sql_stmt := 'UPDATE TEMP_TABLE_ALLE_KT_LPZ SET Gesamtfehlteile = ' || sum_expr;

    -- Führe das dynamische SQL-Statement aus
    EXECUTE IMMEDIATE sql_stmt;
END;
/
