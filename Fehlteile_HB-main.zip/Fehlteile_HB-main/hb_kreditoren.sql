select distinct
tk.SEQUENZ as ORG_SEQUENZNR,
tk.KREDITOR_CODE as ORG_KDNR,
tk.adresse as ORG_ADRESSE,
tk.BELEGNUMMER as ORG_BELEGNUMMER,
tk.notiz as ORG_NOTIZ,
lr.interne_renr as LR_Sequenz,
lr.kdnr as LR_KDNR,
lr.Re_NR as RENR_INTERN,
lr.re_nr_alpha as RENR_LIEFERANT,
TO_CHAR(lr.RE_DATUM, 'DD.MM.YYYY') AS Rechnungsdatum,
lr.WE_NR as WareneingangsNR,
TO_CHAR(lr.WE_DATUM, 'DD.MM.YYYY') as WareneingangsDATUM,
lr.lieferschein_nr as LieferscheinNR,
TO_CHAR(lr.lieferschein_datum, 'DD.MM.YYYY') as Lieferschein_datum,
lp.a_art as Bestellart,
lp.jahr as Bestelljahr,
lp.anr as BestellNR,
lp.posnr as BEstell_PositionsNR,
lp.teilenr as Teilenummer,
lp.re_posnr as RE_PositionsNR,
NVL(lp.menge_bestellt, 0)as Bestellmenge,
NVL(lp.menge_berechnet,0) as Berechnete_Menge,
NVL(wp.menge_geliefert,0) as Liefermenge,
lp.menge_rp_me as Einheit,
lp.epreis_brutto Einzelpreis_Brutto,
lp.pos_wert_brutto GesamtPosition_Brutto,
lp.zusatzkosten as Zusatzkosten_p_GESAMTRECHNUNG,
lp.r_status as Rechnungsstatus
from temp_table_kreditor_hb tk
LEFT JOIN lief_rechnungen lr on lr.interne_renr = tk.sequenz
LEFT join lief_rech_pos lp on lp.re_nr = lr.re_nr
LEFT JOIN wareneingangs_positionen wp 
        ON wp.we_nr = lp.we_nr 
        AND wp.teilenr = lp.teilenr 
        AND wp.a_art = lp.a_art
        AND wp.jahr = lp.jahr
        AND wp.anr = lp.anr
        AND wp.pos_nr = lp.posnr
       

order by org_sequenznr asc

