DECLARE
    v_sql_query VARCHAR2(4000);
BEGIN
    FOR i IN 17..32 LOOP
        -- Dynamische SQL-Abfrage erstellen
        v_sql_query := '
            MERGE INTO temp_table_alle_kt_wsb t
            USING (
                SELECT
                    teilenr,
                    MIN(liefertermin) AS liefertermin -- Jüngstes Datum ermitteln
                FROM (
                    SELECT DISTINCT
                        b.teilenr,
                        b.liefertermin
                    FROM bes_pos b
                    WHERE b.prodauftr LIKE ''KA20191207'||TO_CHAR(i)||'%'' 
                      AND b.status IN (2700, 2710)
                      AND b.a_art IN (''BE'', ''RA'')
                )
                GROUP BY teilenr
            ) s
            ON (t.teilenr = s.teilenr)
            WHEN MATCHED THEN
                UPDATE SET t.Liefertermin_' || TO_CHAR(i) || ' = s.liefertermin'; -- Jüngstes Datum schreiben

        -- Dynamische SQL-Abfrage ausführen
        EXECUTE IMMEDIATE v_sql_query;
    END LOOP;
END;
/
